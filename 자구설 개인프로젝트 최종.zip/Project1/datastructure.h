#ifndef DATA_STRUCTURE__H__
#define DATA_STRUCTURE__H__
#include <iostream>
#include <vector>
#include <cstdio>
#include <fstream>
#include <cstring>
#include <string>
#include <map>
#include <queue>
#include <functional>
using namespace std;
#define INF 987654321
int citycount=0;
vector<pair<int, int>> citylist[50];//vector �����̳� �ȿ� pair �����̳ʸ� �̿��Ͽ� ���������� number�� �װ��ǰ��� ����
map<string, int> citynumbering;
int path[50];
struct city {

	string from;
	string to;
	int charge;

};



string FindKeyByValue(map<string, int> a, int b)
{
	map<string, int>::iterator iter;
	for (iter = a.begin(); iter != a.end(); iter++)
	{

		if (iter->second == b)
		{
			return iter->first;
		}

	}

}



vector<int> FindPath(vector<pair<int, int>> a[50], map<string, int>city, string start, string dest)
{
	int startnumber;
	if (city.find(start) == city.end())
	{
		cout << "������ ������� �������� �ʽ��ϴ�." << endl;
		exit(EXIT_FAILURE);

	}
	if (city.find(dest) == city.end())
	{

		cout << "������ �������� �������� �ʽ��ϴ�." << endl;
		exit(EXIT_FAILURE);

	}
	for (int i = 0; i < 50;i++)
	{
		path[i] = INF;

	}

	startnumber = city[start];

	path[startnumber] = -1;
	vector<int> dist(50, INF);
	dist[startnumber] = 0;
	bool visited[50] = { 0, };


	priority_queue < pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> PQ;

	PQ.push(make_pair(0, startnumber));
	while (!PQ.empty())
	{
		int curr;
		do {

			curr = PQ.top().second;
			PQ.pop();
		} while (!PQ.empty() && visited[curr]);

		if (visited[curr]) break;

		visited[curr] = true;

		for (auto &p : a[curr])
		{

			int next = p.first, d = p.second;

			if (dist[next] > dist[curr] + d)
			{
				dist[next] = dist[curr] + d;
				path[next] = curr;
				PQ.push(make_pair(dist[next], next));


			}


		}

	}

	return dist;

}

void variousPath(vector<pair<int, int>> a[50], map<string, int>city, string start, int budget)
{
	bool visited[50] = { 0, };
	int startnumber;
	int currcost = 0;
	int temp;
	int nextcity;

	startnumber = city[start];
	visited[startnumber] = 1;
	cout << start;
	while (currcost < budget)
	{
		temp = INF;
		for (int i = 0; i < a[startnumber].size(); i++)
		{

			if (a[startnumber][i].second < temp&&visited[a[startnumber][i].first] == 0)
			{

				temp = a[startnumber][i].second;
				nextcity = a[startnumber][i].first;
			}

		}
		if (budget < temp)
		{
			cout << "���������̾����ϴ�..." << endl;
			system("PAUSE");
			exit(EXIT_FAILURE);

		}

		if (currcost + temp < budget)
		{
			currcost += temp;
			startnumber = nextcity;
			visited[startnumber] = 1;
			cout << ">>";
			cout << FindKeyByValue(city, startnumber);
		}
		else
		{
			cout << endl;
			cout << "�������� :" << budget - currcost << endl;
			break;
		}







	}



}

void ReadData(string a)
{

	a += ".txt";
	int cityindex = 0;
	city temp_city;
	ifstream is;
	is.open(a);

	if (is.is_open() == false)
	{



		cout << "�����б� ���� ���α׷��� �����մϴ�." << endl;

		exit(EXIT_FAILURE);



	}

	while (is.eof() == false)
	{


		is >> temp_city.from >> temp_city.to >> temp_city.charge;


		if (citynumbering.find(temp_city.from) == citynumbering.end())
		{


			citynumbering.insert(make_pair(temp_city.from, cityindex++));
			citycount++;

		}


		if (citynumbering.find(temp_city.to) == citynumbering.end())
		{
			citynumbering.insert(make_pair(temp_city.to, cityindex++));
			citycount++;

		}

		citylist[citynumbering[temp_city.from]].push_back(make_pair(citynumbering[temp_city.to], temp_city.charge));

	}

	is.close();

}


#endif
